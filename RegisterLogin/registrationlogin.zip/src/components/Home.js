import React from 'react'

export default function Home() {
  return (
    <div>
      <h2> Home Welcome to MyWorld!...............</h2>
    </div>
  )
}
